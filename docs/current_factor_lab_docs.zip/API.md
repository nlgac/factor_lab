# factor_lab API Reference

Complete API documentation for factor_lab v2.1.0

---

## Table of Contents

1. [Core Types](#core-types)
2. [Decomposition](#decomposition)
3. [Simulation](#simulation)
4. [Optimization](#optimization)
5. [Distributions](#distributions)
6. [I/O Operations](#io-operations)
7. [Validation](#validation)

---

## Core Types

### FactorModelData

The central data structure representing a statistical factor model.

```python
class FactorModelData:
    """
    Complete specification of a statistical factor model.
    
    Attributes
    ----------
    B : np.ndarray, shape (k, p)
        Factor loadings matrix.
    F : np.ndarray, shape (k, k)
        Factor covariance matrix.
    D : np.ndarray, shape (p, p)
        Idiosyncratic covariance matrix.
    factor_transform : Optional[CovarianceTransform]
        Pre-computed square root of F for efficient simulation.
    idio_transform : Optional[CovarianceTransform]
        Pre-computed square root of D for efficient simulation.
    
    Properties
    ----------
    k : int
        Number of factors (read-only).
    p : int
        Number of assets (read-only).
    """
    
    def __init__(self, B, F, D, factor_transform=None, idio_transform=None):
        """
        Create a factor model.
        
        Parameters
        ----------
        B : np.ndarray, shape (k, p)
            Factor loadings.
        F : np.ndarray, shape (k, k)
            Factor covariance.
        D : np.ndarray, shape (p, p)
            Idiosyncratic covariance.
        factor_transform : CovarianceTransform, optional
            Pre-computed F^(1/2).
        idio_transform : CovarianceTransform, optional
            Pre-computed D^(1/2).
        
        Raises
        ------
        ValueError
            If dimensions don't match or matrices are invalid.
        """
    
    def validate(self):
        """Validate internal consistency of the model."""
    
    def implied_covariance(self):
        """
        Compute Σ = B.T @ F @ B + D.
        
        Returns
        -------
        np.ndarray, shape (p, p)
            Full implied covariance matrix.
        
        Warning
        -------
        Creates dense (p, p) matrix. Memory-intensive for large p.
        """
```

**Example:**

```python
import numpy as np
from factor_lab import FactorModelData

B = np.random.randn(3, 50)
F = np.diag([0.04, 0.01, 0.0025])
D = np.diag(np.full(50, 0.01))

model = FactorModelData(B=B, F=F, D=D)
print(f"Model: {model.k} factors × {model.p} assets")

# Get implied covariance
Sigma = model.implied_covariance()
```

---

### OptimizationResult

Result container from portfolio optimization.

```python
@dataclass(frozen=True)
class OptimizationResult:
    """
    Optimization result container.
    
    Attributes
    ----------
    weights : Optional[np.ndarray], shape (p,)
        Optimal portfolio weights. None if optimization failed.
    risk : float
        Portfolio risk (standard deviation).
    objective : float
        Raw objective value from solver.
    solved : bool
        True if optimal solution found.
    metadata : Dict[str, Any]
        Additional solver information.
    """
```

**Example:**

```python
result = optimizer.solve()

if result.solved:
    print(f"Risk: {result.risk:.2%}")
    print(f"Sum of weights: {result.weights.sum():.4f}")
    print(f"Solver status: {result.metadata.get('status')}")
else:
    print("Optimization failed")
```

---

### Scenario

A named collection of optimization constraints.

```python
@dataclass
class Scenario:
    """
    Constraint set for portfolio optimization.
    
    Attributes
    ----------
    name : str
        Human-readable identifier.
    description : str
        Detailed description.
    equality_constraints : List[Tuple[np.ndarray, np.ndarray]]
        List of (A, b) tuples for A @ w == b.
    inequality_constraints : List[Tuple[np.ndarray, np.ndarray]]
        List of (A, b) tuples for A @ w <= b.
    """
    
    def n_equality(self):
        """Count of equality constraints."""
    
    def n_inequality(self):
        """Count of inequality constraints."""
```

---

### CovarianceTransform

Represents square root of covariance for efficient simulation.

```python
@dataclass(frozen=True)
class CovarianceTransform:
    """
    Discriminated union for covariance square root.
    
    Attributes
    ----------
    matrix : np.ndarray
        Either 1D array of std devs (DIAGONAL) or 2D Cholesky factor (DENSE).
    transform_type : TransformType
        DIAGONAL or DENSE indicator.
    """
    
    @property
    def is_diagonal(self):
        """Check if this is a diagonal transform."""
    
    def apply(self, z):
        """
        Apply transform to standardized samples.
        
        Parameters
        ----------
        z : np.ndarray, shape (n, d)
            Standardized samples (mean=0, var=1).
        
        Returns
        -------
        np.ndarray, shape (n, d)
            Transformed samples with target covariance.
        """
```

---

## Decomposition

### svd_decomposition

Extract factors using Singular Value Decomposition.

```python
def svd_decomposition(
    returns: np.ndarray,
    k: int,
    demean: bool = True
) -> FactorModelData:
    """
    Extract k factors from returns using SVD.
    
    Parameters
    ----------
    returns : np.ndarray, shape (T, p)
        Historical returns matrix.
    k : int
        Number of factors to extract.
    demean : bool, default=True
        Whether to demean returns before decomposition.
    
    Returns
    -------
    FactorModelData
        Factor model with pre-computed diagonal transforms.
    
    Notes
    -----
    SVD is numerically more stable than eigendecomposition
    and directly provides square roots needed for simulation.
    
    The explained variance ratio is k / p when using all singular values.
    """
```

**Example:**

```python
from factor_lab import svd_decomposition
import numpy as np

# Generate or load returns
returns = np.random.randn(1000, 100)

# Extract 5-factor model
model = svd_decomposition(returns, k=5)

# Check explained variance
from factor_lab import compute_explained_variance
var_explained = compute_explained_variance(returns, model)
print(f"5 factors explain {var_explained:.1%} of variance")
```

---

### pca_decomposition

Extract factors using Principal Component Analysis.

```python
def pca_decomposition(
    cov_matrix: np.ndarray,
    k: int,
    method: PCAMethod = PCAMethod.NUMPY
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Extract k factors from covariance matrix using PCA.
    
    Parameters
    ----------
    cov_matrix : np.ndarray, shape (p, p)
        Sample covariance matrix.
    k : int
        Number of factors to extract.
    method : PCAMethod, default=NUMPY
        Solver method: NUMPY or SCIPY.
    
    Returns
    -------
    B : np.ndarray, shape (k, p)
        Factor loadings (eigenvectors).
    F : np.ndarray, shape (k, k)
        Factor covariance (diagonal of eigenvalues).
    
    Notes
    -----
    Returns only B and F. User must compute D = Σ - B.T @ F @ B.
    """
```

**Example:**

```python
from factor_lab import pca_decomposition, PCAMethod
import numpy as np

# Compute sample covariance
returns = np.random.randn(1000, 50)
cov = np.cov(returns, rowvar=False)

# Extract 3 factors
B, F = pca_decomposition(cov, k=3, method=PCAMethod.SCIPY)

# Compute residual
D = cov - B.T @ F @ B
D = np.diag(np.diag(D))  # Diagonalize

# Create model
from factor_lab import FactorModelData
model = FactorModelData(B=B, F=F, D=D)
```

---

### compute_explained_variance

Calculate variance explained by factor model.

```python
def compute_explained_variance(
    returns: np.ndarray,
    model: FactorModelData
) -> float:
    """
    Compute proportion of variance explained by factors.
    
    Parameters
    ----------
    returns : np.ndarray, shape (T, p)
        Historical returns.
    model : FactorModelData
        Factor model to evaluate.
    
    Returns
    -------
    float
        Proportion of variance explained (0 to 1).
    """
```

---

### select_k_by_variance

Automatically select number of factors.

```python
def select_k_by_variance(
    returns: np.ndarray,
    threshold: float = 0.90,
    max_k: Optional[int] = None
) -> int:
    """
    Select k to explain a target proportion of variance.
    
    Parameters
    ----------
    returns : np.ndarray, shape (T, p)
        Historical returns.
    threshold : float, default=0.90
        Target proportion of variance to explain.
    max_k : int, optional
        Maximum number of factors to consider.
    
    Returns
    -------
    int
        Selected number of factors.
    
    Example
    -------
    >>> k = select_k_by_variance(returns, threshold=0.95)
    >>> print(f"Need {k} factors to explain 95% of variance")
    """
```

---

## Simulation

### ReturnsSimulator

Monte Carlo simulator for factor model returns.

```python
class ReturnsSimulator:
    """
    Generate synthetic returns from a factor model.
    
    Parameters
    ----------
    model : FactorModelData
        Factor model specification.
    rng : np.random.Generator, optional
        Random number generator for reproducibility.
    force_dense : bool, default=False
        Force use of dense Cholesky even for diagonal covariances.
    """
    
    def __init__(
        self,
        model: FactorModelData,
        rng: Optional[np.random.Generator] = None,
        force_dense: bool = False
    ):
        """Initialize the simulator."""
    
    def simulate(
        self,
        n_periods: int,
        factor_samplers: List[SamplerCallable],
        idio_samplers: List[SamplerCallable]
    ) -> Dict[str, np.ndarray]:
        """
        Simulate returns for n_periods.
        
        Parameters
        ----------
        n_periods : int
            Number of periods to simulate.
        factor_samplers : List[SamplerCallable]
            One sampler per factor. Each returns standardized draws.
        idio_samplers : List[SamplerCallable]
            One sampler per asset. Each returns standardized draws.
        
        Returns
        -------
        dict with keys:
            'security_returns' : np.ndarray, shape (n_periods, p)
                Simulated asset returns.
            'factor_returns' : np.ndarray, shape (n_periods, k)
                Simulated factor returns.
            'idio_returns' : np.ndarray, shape (n_periods, p)
                Simulated idiosyncratic returns.
        
        Notes
        -----
        Samplers should return STANDARDIZED draws (mean=0, var=1).
        The simulator applies the appropriate scaling from F and D.
        """
```

**Example:**

```python
from factor_lab import ReturnsSimulator, DistributionFactory
import numpy as np

rng = np.random.default_rng(42)
factory = DistributionFactory(rng=rng)

# Create samplers (standardized)
factor_samplers = [factory.create("normal", mean=0, std=1) for _ in range(model.k)]
idio_samplers = [factory.create("student_t", df=5) for _ in range(model.p)]

# Simulate
simulator = ReturnsSimulator(model, rng=rng)
results = simulator.simulate(252, factor_samplers, idio_samplers)

print(f"Simulated {results['security_returns'].shape[0]} periods")
```

---

### simulate_returns

Convenience function for quick simulation.

```python
def simulate_returns(
    model: FactorModelData,
    n_periods: int,
    rng: Optional[np.random.Generator] = None,
    innovation: str = "normal"
) -> np.ndarray:
    """
    Quick simulation with standard innovations.
    
    Parameters
    ----------
    model : FactorModelData
        Factor model.
    n_periods : int
        Number of periods.
    rng : np.random.Generator, optional
        RNG for reproducibility.
    innovation : str, default="normal"
        Innovation type: "normal", "student_t", "laplace".
    
    Returns
    -------
    np.ndarray, shape (n_periods, p)
        Simulated security returns only.
    
    Example
    -------
    >>> returns = simulate_returns(model, 252, innovation="student_t")
    """
```

---

## Optimization

### FactorOptimizer

SOCP-based portfolio optimizer exploiting factor structure.

```python
class FactorOptimizer:
    """
    Minimum variance portfolio optimizer using factor models.
    
    Parameters
    ----------
    model : FactorModelData
        Factor model specification.
    
    Methods
    -------
    apply_scenario(scenario)
        Apply a constraint scenario.
    add_equality_constraint(A, b)
        Add A @ w == b constraint.
    add_inequality_constraint(A, b)
        Add A @ w <= b constraint.
    reset_constraints()
        Clear all constraints.
    solve()
        Solve the optimization problem.
    """
    
    def __init__(self, model: FactorModelData):
        """Initialize optimizer."""
    
    def apply_scenario(self, scenario: Scenario):
        """
        Apply a pre-built scenario.
        
        Parameters
        ----------
        scenario : Scenario
            Constraint scenario to apply.
        """
    
    def add_equality_constraint(self, A: np.ndarray, b: np.ndarray):
        """
        Add equality constraint A @ w == b.
        
        Parameters
        ----------
        A : np.ndarray, shape (m, p)
            Constraint matrix.
        b : np.ndarray, shape (m,)
            Constraint vector.
        """
    
    def add_inequality_constraint(self, A: np.ndarray, b: np.ndarray):
        """
        Add inequality constraint A @ w <= b.
        
        Parameters
        ----------
        A : np.ndarray, shape (m, p)
            Constraint matrix.
        b : np.ndarray, shape (m,)
            Constraint vector.
        """
    
    def reset_constraints(self):
        """Remove all constraints."""
    
    def solve(self) -> OptimizationResult:
        """
        Solve the optimization problem.
        
        Returns
        -------
        OptimizationResult
            Result containing weights, risk, and solver metadata.
        """
```

**Example:**

```python
from factor_lab import FactorOptimizer
import numpy as np

optimizer = FactorOptimizer(model)

# Add constraints manually
p = model.p
optimizer.add_equality_constraint(
    A=np.ones((1, p)),
    b=np.array([1.0])
)  # Fully invested

optimizer.add_inequality_constraint(
    A=-np.eye(p),
    b=np.zeros(p)
)  # No short sales

# Solve
result = optimizer.solve()
```

---

### ScenarioBuilder

Fluent API for building constraint scenarios.

```python
class ScenarioBuilder:
    """
    Builder for optimization scenarios.
    
    Parameters
    ----------
    p : int
        Number of assets.
    
    Methods
    -------
    create(name, description="")
        Start a new scenario.
    add_fully_invested()
        Add sum(w) == 1 constraint.
    add_long_only()
        Add w >= 0 constraint.
    add_box_constraints(low, high)
        Add low <= w <= high constraint.
    add_sector_neutral(sector_matrix, sector_budgets)
        Add sector neutrality constraints.
    add_custom_equality(A, b)
        Add custom A @ w == b.
    add_custom_inequality(A, b)
        Add custom A @ w <= b.
    build()
        Finalize and return the scenario.
    """
    
    def __init__(self, p: int):
        """Initialize builder."""
    
    def create(self, name: str, description: str = ""):
        """
        Start building a new scenario.
        
        Parameters
        ----------
        name : str
            Scenario name.
        description : str, optional
            Scenario description.
        
        Returns
        -------
        self
            For method chaining.
        """
    
    def add_fully_invested(self):
        """
        Add fully invested constraint: sum(w) == 1.
        
        Returns
        -------
        self
            For method chaining.
        """
    
    def add_long_only(self):
        """
        Add long-only constraint: w >= 0.
        
        Returns
        -------
        self
            For method chaining.
        """
    
    def add_box_constraints(self, low: float, high: float):
        """
        Add box constraints: low <= w_i <= high for all i.
        
        Parameters
        ----------
        low : float
            Lower bound for each weight.
        high : float
            Upper bound for each weight.
        
        Returns
        -------
        self
            For method chaining.
        
        Raises
        ------
        ValueError
            If low > high.
        """
    
    def add_sector_neutral(
        self,
        sector_matrix: np.ndarray,
        sector_budgets: Optional[np.ndarray] = None
    ):
        """
        Add sector neutrality constraints.
        
        Parameters
        ----------
        sector_matrix : np.ndarray, shape (n_sectors, p)
            Binary matrix indicating sector membership.
        sector_budgets : np.ndarray, shape (n_sectors,), optional
            Target exposure per sector. Defaults to zero.
        
        Returns
        -------
        self
            For method chaining.
        """
    
    def build(self) -> Scenario:
        """
        Finalize and return the scenario.
        
        Returns
        -------
        Scenario
            The constructed scenario.
        
        Raises
        ------
        ValueError
            If create() was not called first.
        """
```

**Example:**

```python
from factor_lab import ScenarioBuilder

builder = ScenarioBuilder(p=100)

# Fluent chaining
scenario = (builder
    .create("Conservative Long-Only")
    .add_fully_invested()
    .add_long_only()
    .add_box_constraints(low=0.0, high=0.05)  # Max 5% per position
    .build())

print(f"Scenario '{scenario.name}' with {scenario.n_inequality()} constraints")
```

---

### minimum_variance_portfolio

Convenience function for quick optimization.

```python
def minimum_variance_portfolio(
    model: FactorModelData,
    long_only: bool = True,
    max_weight: Optional[float] = None
) -> OptimizationResult:
    """
    Quick minimum variance optimization with common constraints.
    
    Parameters
    ----------
    model : FactorModelData
        Factor model.
    long_only : bool, default=True
        If True, add w >= 0 constraint.
    max_weight : float, optional
        Maximum weight per asset.
    
    Returns
    -------
    OptimizationResult
        Optimization result.
    
    Example
    -------
    >>> result = minimum_variance_portfolio(model, max_weight=0.10)
    """
```

---

## Distributions

### DistributionFactory

Create sampler functions for various distributions.

```python
class DistributionFactory:
    """
    Factory for creating distribution samplers.
    
    Parameters
    ----------
    rng : np.random.Generator, optional
        Random number generator.
    """
    
    def __init__(self, rng: Optional[np.random.Generator] = None):
        """Initialize factory."""
    
    def create(self, name: str, **params) -> SamplerCallable:
        """
        Create a sampler function.
        
        Parameters
        ----------
        name : str
            Distribution name (case-insensitive).
        **params
            Distribution-specific parameters.
        
        Returns
        -------
        SamplerCallable
            Function that takes size and returns samples.
        
        Supported Distributions
        -----------------------
        - "normal": mean, std
        - "student_t": df
        - "uniform": low, high
        - "exponential": scale
        - "beta": alpha, beta
        - "constant": value
        
        Example
        -------
        >>> factory = DistributionFactory(rng=np.random.default_rng(42))
        >>> sampler = factory.create("normal", mean=0.0, std=1.0)
        >>> samples = sampler(1000)  # 1000 samples
        """
    
    def list_distributions(self) -> List[str]:
        """List available distributions."""
```

**Example:**

```python
from factor_lab import DistributionFactory
import numpy as np

rng = np.random.default_rng(42)
factory = DistributionFactory(rng=rng)

# Create various samplers
normal = factory.create("normal", mean=0, std=1)
student_t = factory.create("student_t", df=5)
uniform = factory.create("uniform", low=-1, high=1)

# Use them
samples_n = normal(1000)
samples_t = student_t(1000)
samples_u = uniform(1000)

print(f"Available: {factory.list_distributions()}")
```

---

### DistributionRegistry

Global registry of available distributions.

```python
class DistributionRegistry:
    """
    Registry of probability distributions.
    
    Methods
    -------
    register(name, func, required_params, optional_params, description)
        Register a custom distribution.
    get(name)
        Get distribution info by name.
    list_distributions()
        List all registered distributions.
    """
    
    def register(
        self,
        name: str,
        func: Callable,
        required_params: Set[str],
        optional_params: Dict[str, Any] = None,
        description: str = ""
    ):
        """
        Register a custom distribution.
        
        Parameters
        ----------
        name : str
            Distribution name.
        func : Callable
            Function with signature: func(rng, size, **params).
        required_params : Set[str]
            Required parameter names.
        optional_params : Dict[str, Any], optional
            Optional parameters with defaults.
        description : str, optional
            Human-readable description.
        """
```

---

### DataSampler

Generate synthetic factor model data.

```python
class DataSampler:
    """
    Generate synthetic factor models for testing.
    
    Parameters
    ----------
    p : int
        Number of assets.
    k : int
        Number of factors.
    rng : np.random.Generator, optional
        Random number generator.
    """
    
    def configure(
        self,
        beta: Union[SamplerCallable, List[SamplerCallable]],
        factor_vol: Union[SamplerCallable, List[SamplerCallable]],
        idio_vol: Union[SamplerCallable, List[SamplerCallable]]
    ):
        """
        Configure the data generation.
        
        Parameters
        ----------
        beta : SamplerCallable or List[SamplerCallable]
            Sampler(s) for factor loadings.
        factor_vol : SamplerCallable or List[SamplerCallable]
            Sampler(s) for factor volatilities.
        idio_vol : SamplerCallable or List[SamplerCallable]
            Sampler(s) for idiosyncratic volatilities.
        
        Returns
        -------
        self
            For method chaining.
        """
    
    def generate(self) -> FactorModelData:
        """
        Generate the factor model.
        
        Returns
        -------
        FactorModelData
            Randomly generated factor model.
        """
```

**Example:**

```python
from factor_lab import DataSampler, DistributionFactory
import numpy as np

rng = np.random.default_rng(42)
factory = DistributionFactory(rng=rng)

sampler = DataSampler(p=100, k=3, rng=rng)
model = (sampler
    .configure(
        beta=factory.create("normal", mean=0, std=1),
        factor_vol=factory.create("uniform", low=0.1, high=0.3),
        idio_vol=factory.create("constant", value=0.05)
    )
    .generate())

print(f"Generated model: {model.k} × {model.p}")
```

---

## I/O Operations

### save_model

Save a factor model to disk.

```python
def save_model(
    model: FactorModelData,
    path: Union[str, Path],
    format: ModelFormat = ModelFormat.NPZ
):
    """
    Save factor model to disk.
    
    Parameters
    ----------
    model : FactorModelData
        Model to save.
    path : str or Path
        Destination file path.
    format : ModelFormat, default=ModelFormat.NPZ
        File format (NPZ or JSON).
    
    Notes
    -----
    NPZ format preserves covariance transforms.
    JSON format does not preserve transforms but is human-readable.
    
    Example
    -------
    >>> save_model(model, "my_model.npz")
    >>> save_model(model, "my_model.json", format=ModelFormat.JSON)
    """
```

---

### load_model

Load a factor model from disk.

```python
def load_model(path: Union[str, Path]) -> FactorModelData:
    """
    Load factor model from disk.
    
    Parameters
    ----------
    path : str or Path
        Source file path. Format inferred from extension.
    
    Returns
    -------
    FactorModelData
        Loaded factor model.
    
    Raises
    ------
    FileNotFoundError
        If file doesn't exist.
    ValueError
        If format is unknown.
    
    Example
    -------
    >>> model = load_model("my_model.npz")
    >>> print(f"Loaded {model.k}×{model.p} model")
    """
```

---

## Validation

### CovarianceValidator

Validate empirical vs. model-implied covariance.

```python
class CovarianceValidator:
    """
    Validator for covariance structure.
    
    Parameters
    ----------
    model : FactorModelData
        Factor model to validate against.
    """
    
    def __init__(self, model: FactorModelData):
        """Initialize validator."""
    
    def compare(self, returns: np.ndarray) -> CovarianceValidationResult:
        """
        Compare empirical vs. model covariance.
        
        Parameters
        ----------
        returns : np.ndarray, shape (T, p)
            Simulated or historical returns.
        
        Returns
        -------
        CovarianceValidationResult
            Validation metrics.
        
        Raises
        ------
        ValueError
            If returns shape doesn't match model.
        """
    
    def reset_cache(self):
        """Clear cached model covariance."""
```

---

### CovarianceValidationResult

Result from covariance validation.

```python
@dataclass(frozen=True)
class CovarianceValidationResult:
    """
    Covariance validation metrics.
    
    Attributes
    ----------
    frobenius_error : float
        Frobenius norm ||empirical - model||.
    mean_absolute_error : float
        Average element-wise error.
    max_absolute_error : float
        Maximum element-wise error.
    explained_variance_ratio : float
        Proportion of variance explained by factors.
    model_covariance : np.ndarray
        Model-implied covariance.
    empirical_covariance : np.ndarray
        Sample covariance from returns.
    """
```

**Example:**

```python
from factor_lab import CovarianceValidator

validator = CovarianceValidator(model)
validation = validator.compare(simulated_returns)

print(f"Frobenius error: {validation.frobenius_error:.4f}")
print(f"Explained variance: {validation.explained_variance_ratio:.2%}")

if validation.mean_absolute_error > 0.1:
    print("Warning: Large covariance error!")
```

---

## Enums and Constants

### ModelFormat

```python
class ModelFormat(str, Enum):
    """Supported model file formats."""
    NPZ = "npz"    # Binary NumPy format (preserves transforms)
    JSON = "json"  # Human-readable JSON format
```

### TransformType

```python
class TransformType(Enum):
    """Covariance transform types."""
    DIAGONAL = auto()  # O(n) simulation
    DENSE = auto()     # O(n²) simulation
```

### PCAMethod

```python
class PCAMethod(str, Enum):
    """PCA solver methods."""
    NUMPY = "numpy"    # NumPy's eigh
    SCIPY = "scipy"    # SciPy's subset eigenvalue solver
```

---

## Type Aliases

```python
# Sampler function type
SamplerCallable = Callable[[Union[int, Tuple[int, ...]]], np.ndarray]
```

A sampler is a function that takes a size specification and returns samples:

```python
def my_sampler(size):
    """Example sampler."""
    if isinstance(size, int):
        return np.random.randn(size)
    else:
        return np.random.randn(*size)

# Use as:
samples_1d = my_sampler(100)          # shape (100,)
samples_2d = my_sampler((10, 5))      # shape (10, 5)
```

---

## Error Handling

Common exceptions raised by factor_lab:

```python
ValueError
    - Invalid dimensions in FactorModelData
    - Constraint validation failures in ScenarioBuilder
    - Missing required parameters in DistributionFactory
    - Invalid k selection

FileNotFoundError
    - Model file doesn't exist in load_model

TypeError
    - Invalid types passed to functions
    - Non-callable samplers

RuntimeError
    - CVXPY solver failures in optimization
```

---

**Version**: 2.1.0 | **Last Updated**: January 2026
