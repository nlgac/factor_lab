# factor_lab Cheatsheet

Quick reference for common tasks in factor_lab v2.1.0

---

## 🚀 Quick Start

### Installation

```bash
pip install -e .
```

### Basic Imports

```python
import numpy as np
from factor_lab import (
    # Core
    FactorModelData,
    
    # Decomposition
    svd_decomposition,
    pca_decomposition,
    
    # Simulation
    ReturnsSimulator,
    simulate_returns,
    DistributionFactory,
    
    # Optimization
    FactorOptimizer,
    ScenarioBuilder,
    minimum_variance_portfolio,
    
    # I/O
    save_model,
    load_model,
    
    # Validation
    CovarianceValidator,
)
```

---

## 📊 Factor Model Creation

### From Returns (SVD)

```python
# Extract k-factor model from historical returns
returns = np.random.randn(1000, 100)  # T × p
model = svd_decomposition(returns, k=5)
```

### From Covariance (PCA)

```python
# Extract factors from covariance matrix
cov = np.cov(returns, rowvar=False)
B, F = pca_decomposition(cov, k=5)

# Complete the model
D = cov - B.T @ F @ B
D = np.diag(np.diag(D))  # Diagonalize
model = FactorModelData(B=B, F=F, D=D)
```

### Manual Construction

```python
# Build model from scratch
k, p = 3, 50
B = np.random.randn(k, p)
F = np.diag([0.04, 0.01, 0.0025])
D = np.diag(np.full(p, 0.01))

model = FactorModelData(B=B, F=F, D=D)
```

---

## 🎲 Simulation

### Quick Simulation (Normal)

```python
# Simulate with Gaussian innovations
returns = simulate_returns(model, n_periods=252)
```

### Custom Distributions

```python
# Setup
rng = np.random.default_rng(42)
factory = DistributionFactory(rng=rng)

# Create samplers
factor_samplers = [
    factory.create("student_t", df=5)
    for _ in range(model.k)
]
idio_samplers = [
    factory.create("normal", mean=0, std=1)
    for _ in range(model.p)
]

# Simulate
simulator = ReturnsSimulator(model, rng=rng)
results = simulator.simulate(252, factor_samplers, idio_samplers)

# Access components
security_returns = results["security_returns"]  # (T, p)
factor_returns = results["factor_returns"]      # (T, k)
idio_returns = results["idio_returns"]          # (T, p)
```

### Available Distributions

```python
factory.create("normal", mean=0, std=1)
factory.create("student_t", df=5)
factory.create("uniform", low=-1, high=1)
factory.create("exponential", scale=1.0)
factory.create("beta", alpha=2, beta=5)
factory.create("constant", value=0.05)
```

---

## 📈 Portfolio Optimization

### Quick Optimization

```python
# Long-only minimum variance
result = minimum_variance_portfolio(model, max_weight=0.10)

if result.solved:
    weights = result.weights
    risk = result.risk
```

### Custom Constraints

```python
# Using ScenarioBuilder
builder = ScenarioBuilder(p=model.p)

scenario = (builder
    .create("130/30 Strategy")
    .add_fully_invested()
    .add_box_constraints(low=-0.30, high=1.30)
    .build())

optimizer = FactorOptimizer(model)
optimizer.apply_scenario(scenario)
result = optimizer.solve()
```

### Common Scenarios

```python
# Long-only, fully invested
scenario = (ScenarioBuilder(p)
    .create("Long Only")
    .add_fully_invested()
    .add_long_only()
    .build())

# Long-only with position limits
scenario = (ScenarioBuilder(p)
    .create("Diversified Long")
    .add_fully_invested()
    .add_long_only()
    .add_box_constraints(low=0, high=0.05)  # Max 5%
    .build())

# 130/30 (130% long, 30% short)
scenario = (ScenarioBuilder(p)
    .create("130/30")
    .add_fully_invested()
    .add_box_constraints(low=-0.30, high=1.30)
    .build())

# Sector neutral
sector_matrix = np.zeros((n_sectors, p))
# ... fill sector_matrix ...
scenario = (ScenarioBuilder(p)
    .create("Sector Neutral")
    .add_fully_invested()
    .add_sector_neutral(sector_matrix)
    .build())
```

### Manual Constraints

```python
optimizer = FactorOptimizer(model)

# Fully invested: sum(w) = 1
optimizer.add_equality_constraint(
    A=np.ones((1, p)),
    b=np.array([1.0])
)

# No short sales: w >= 0
optimizer.add_inequality_constraint(
    A=-np.eye(p),
    b=np.zeros(p)
)

# Max 10% per position: w <= 0.1
optimizer.add_inequality_constraint(
    A=np.eye(p),
    b=np.full(p, 0.1)
)

result = optimizer.solve()
```

---

## 💾 Saving and Loading

### Save Model

```python
# NPZ format (binary, preserves transforms)
save_model(model, "model.npz")

# JSON format (human-readable)
from factor_lab import ModelFormat
save_model(model, "model.json", format=ModelFormat.JSON)
```

### Load Model

```python
# Automatically detects format from extension
model = load_model("model.npz")
```

### Save Simulation Results

```python
# Complete simulation data
np.savez('simulation.npz',
         security_returns=security_returns,
         factor_returns=factor_returns,
         idio_returns=idio_returns,
         B=model.B,
         F=model.F,
         D=model.D)

# Just returns as CSV
np.savetxt('returns.csv', security_returns, delimiter=',')
```

---

## ✅ Validation

### Validate Covariance

```python
validator = CovarianceValidator(model)
validation = validator.compare(simulated_returns)

print(f"Frobenius error: {validation.frobenius_error:.4f}")
print(f"Mean error: {validation.mean_absolute_error:.4f}")
print(f"Explained variance: {validation.explained_variance_ratio:.2%}")
```

### Verify Model Structure

```python
# Check r = B.T @ f + ε
reconstructed = (model.B.T @ factor_returns.T).T + idio_returns
error = np.abs(security_returns - reconstructed).max()
print(f"Reconstruction error: {error:.10f}")  # Should be ~0

# Check Σ = B.T @ F @ B + D
empirical_cov = np.cov(security_returns, rowvar=False)
model_cov = model.implied_covariance()
cov_error = np.linalg.norm(empirical_cov - model_cov, 'fro')
print(f"Covariance error: {cov_error:.4f}")
```

### Explained Variance

```python
from factor_lab import compute_explained_variance

var_explained = compute_explained_variance(returns, model)
print(f"{model.k} factors explain {var_explained:.1%} of variance")
```

---

## 🛠️ Utilities

### Select Number of Factors

```python
from factor_lab import select_k_by_variance

# Choose k to explain 90% of variance
k = select_k_by_variance(returns, threshold=0.90)
print(f"Need {k} factors for 90% variance explained")
```

### Generate Synthetic Data

```python
from factor_lab import DataSampler

rng = np.random.default_rng(42)
factory = DistributionFactory(rng=rng)

sampler = DataSampler(p=100, k=3, rng=rng)
model = (sampler
    .configure(
        beta=factory.create("normal", mean=0, std=1),
        factor_vol=factory.create("uniform", low=0.1, high=0.3),
        idio_vol=factory.create("constant", value=0.05)
    )
    .generate())
```

### Check Model Properties

```python
print(f"Factors: {model.k}")
print(f"Assets: {model.p}")
print(f"Factor variances: {np.diag(model.F)}")
print(f"Idio variances: {np.diag(model.D)[:5]}")  # First 5

# Implied covariance (WARNING: memory intensive for large p)
if model.p < 500:
    Sigma = model.implied_covariance()
    print(f"Total variance: {np.trace(Sigma) / model.p:.6f}")
```

---

## 🎯 Common Workflows

### Workflow 1: Extract → Optimize → Backtest

```python
# 1. Extract factors from historical data
model = svd_decomposition(historical_returns, k=5)

# 2. Optimize portfolio
scenario = (ScenarioBuilder(model.p)
    .create("Long Only")
    .add_fully_invested()
    .add_long_only()
    .add_box_constraints(0, 0.10)
    .build())

optimizer = FactorOptimizer(model)
optimizer.apply_scenario(scenario)
result = optimizer.solve()

# 3. Save results
save_model(model, "latest_model.npz")
np.save("optimal_weights.npy", result.weights)
```

### Workflow 2: Simulate → Validate → Analyze

```python
# 1. Create or load model
model = load_model("model.npz")

# 2. Simulate
rng = np.random.default_rng(42)
factory = DistributionFactory(rng=rng)

f_samp = [factory.create("normal", mean=0, std=1) for _ in range(model.k)]
i_samp = [factory.create("student_t", df=5) for _ in range(model.p)]

simulator = ReturnsSimulator(model, rng=rng)
results = simulator.simulate(252, f_samp, i_samp)

# 3. Validate
validator = CovarianceValidator(model)
validation = validator.compare(results["security_returns"])

# 4. Analyze
print(f"Frobenius error: {validation.frobenius_error:.4f}")

# Save for analysis
np.savez('results.npz', **results)
```

### Workflow 3: Build → Test → Iterate

```python
# 1. Build candidate models with different k
models = {}
for k in [3, 5, 10, 20]:
    models[k] = svd_decomposition(returns, k=k)

# 2. Evaluate each
for k, model in models.items():
    var_exp = compute_explained_variance(returns, model)
    result = minimum_variance_portfolio(model)
    print(f"k={k}: {var_exp:.1%} variance, risk={result.risk:.2%}")

# 3. Select best
best_k = 5  # Based on analysis
final_model = models[best_k]
```

---

## 🔧 Debugging

### Check Dimensions

```python
print(f"B shape: {model.B.shape}")  # Should be (k, p)
print(f"F shape: {model.F.shape}")  # Should be (k, k)
print(f"D shape: {model.D.shape}")  # Should be (p, p)
```

### Verify Constraints

```python
scenario = builder.build()
print(f"Equality constraints: {scenario.n_equality()}")
print(f"Inequality constraints: {scenario.n_inequality()}")

# Check a specific constraint
for A, b in scenario.equality_constraints:
    print(f"  Shape: A={A.shape}, b={b.shape}")
```

### Optimization Troubleshooting

```python
result = optimizer.solve()

if not result.solved:
    print(f"Status: {result.metadata.get('status')}")
    print(f"Solver: {result.metadata.get('solver')}")
    
    # Try with looser constraints
    optimizer.reset_constraints()
    # ... add fewer/looser constraints ...
```

---

## 📚 Quick Reference Tables

### Constraint Patterns

| Constraint | Code |
|------------|------|
| Fully invested | `add_fully_invested()` |
| Long only | `add_long_only()` |
| Max position | `add_box_constraints(0, 0.10)` |
| 130/30 | `add_box_constraints(-0.30, 1.30)` |
| Sector neutral | `add_sector_neutral(matrix)` |

### Distribution Parameters

| Distribution | Required Params | Optional Params |
|-------------|----------------|-----------------|
| normal | mean, std | - |
| student_t | df | - |
| uniform | low, high | - |
| exponential | scale | - |
| beta | alpha, beta | - |
| constant | value | - |

### File Formats

| Format | Extension | Preserves Transforms | Human Readable |
|--------|-----------|---------------------|----------------|
| NPZ | .npz | ✅ Yes | ❌ No |
| JSON | .json | ❌ No | ✅ Yes |

---

## 💡 Pro Tips

### Performance

```python
# Use factor structure for large p
# O(k²) vs O(p²) for full covariance

# Example: p=1000, k=10
# Factor optimization: ~100x faster
# Factor simulation: ~10,000x faster
```

### Reproducibility

```python
# Always use explicit RNG
rng = np.random.default_rng(42)

# Pass to all random operations
factory = DistributionFactory(rng=rng)
simulator = ReturnsSimulator(model, rng=rng)
sampler = DataSampler(p, k, rng=rng)
```

### Memory Management

```python
# Avoid full covariance for large p
# Use: model.B, model.F, model.D separately
# Instead of: model.implied_covariance()

# Only compute when necessary
if model.p < 500:
    Sigma = model.implied_covariance()
```

### Numerical Stability

```python
# Prefer SVD over PCA on returns
model = svd_decomposition(returns, k=5)  # More stable

# Instead of:
cov = np.cov(returns, rowvar=False)
B, F = pca_decomposition(cov, k=5)  # Less stable for ill-conditioned cov
```

---

## 🚨 Common Pitfalls

### ❌ Wrong Dimensions

```python
# WRONG: B is (p, k) instead of (k, p)
B = np.random.randn(100, 3)  # DON'T DO THIS

# CORRECT: B is (k, p)
B = np.random.randn(3, 100)  # Do this
```

### ❌ Forgot to Standardize Samplers

```python
# WRONG: Non-standardized sampler
sampler = factory.create("normal", mean=5, std=2)

# CORRECT: Standardized (mean=0, std=1)
sampler = factory.create("normal", mean=0, std=1)
# Simulator applies the correct scaling from F and D
```

### ❌ Inconsistent Shapes

```python
# WRONG: Mismatch between model.p and constraint dimensions
scenario = ScenarioBuilder(p=50).create("test").build()
optimizer = FactorOptimizer(model)  # model.p = 100
optimizer.apply_scenario(scenario)  # ERROR!

# CORRECT: Match dimensions
scenario = ScenarioBuilder(p=model.p).create("test").build()
```

### ❌ Forgot to Call build()

```python
# WRONG: Forgot to build scenario
builder = ScenarioBuilder(p).create("test").add_fully_invested()
optimizer.apply_scenario(builder)  # ERROR!

# CORRECT: Always call build()
scenario = builder.build()
optimizer.apply_scenario(scenario)
```

---

## 📞 Getting Help

```python
# Check documentation
help(FactorModelData)
help(FactorOptimizer.solve)

# List available distributions
factory = DistributionFactory()
print(factory.list_distributions())

# Inspect model
print(model)  # Shows dimensions
model.validate()  # Raises error if invalid
```

---

**Version**: 2.1.0 | **Last Updated**: January 2026

**Quick Links**:
- [Full API Reference](API.md)
- [Complete README](README.md)
- [Examples](examples/)
