# factor_lab

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-2.1.0-orange.svg)](CHANGELOG.md)

A comprehensive Python library for factor model construction, portfolio optimization, and Monte Carlo simulation in quantitative finance.

## 🎯 Overview

`factor_lab` provides a complete toolkit for working with statistical factor models in portfolio management and risk analysis. It implements efficient algorithms for:

- **Factor Extraction**: PCA and SVD-based decomposition of returns into systematic and idiosyncratic components
- **Portfolio Optimization**: Fast SOCP-based minimum variance optimization using factor structure
- **Monte Carlo Simulation**: Generate synthetic returns with flexible innovation distributions
- **Model Serialization**: Save and load models with full transform preservation
- **Covariance Validation**: Comprehensive diagnostics for model quality

## 🚀 Key Features

### 📊 Factor Model Construction
- **SVD Decomposition**: Numerically stable factor extraction from returns data
- **PCA Decomposition**: Eigenvalue-based factor analysis with variance explained metrics
- **Automatic k Selection**: Choose number of factors based on variance threshold
- **Transform Caching**: Pre-compute Cholesky/diagonal transforms for O(n) simulation

### 🎲 Monte Carlo Simulation
- **Flexible Innovations**: Gaussian, Student-t, exponential, beta, and custom distributions
- **Efficient Simulation**: O(k²) complexity using factor structure vs. O(p²) full covariance
- **Hybrid Paths**: Automatic detection of diagonal vs. dense covariance structures
- **Reproducibility**: Explicit RNG management for deterministic results

### 📈 Portfolio Optimization
- **SOCP Formulation**: Second-order cone programming for minimum variance portfolios
- **Rich Constraints**: Long-only, box constraints, sector neutrality, leverage limits
- **Scenario Builder**: Fluent API for constructing complex constraint sets
- **Factor Efficiency**: Exploits B.T @ F @ B + D structure for large universes

### 💾 Model Persistence
- **NPZ Format**: Fast binary format preserving all transforms and metadata
- **JSON Format**: Human-readable export for inspection and sharing
- **Automatic Detection**: Load models based on file extension
- **Round-trip Integrity**: Perfect reconstruction of saved models

## 📦 Installation

### From Source (Development)

```bash
git clone https://github.com/yourusername/factor_lab.git
cd factor_lab
pip install -e .
```

### Requirements

- Python 3.8+
- NumPy >= 1.20
- SciPy >= 1.7
- CVXPY >= 1.2

## 🏃 Quick Start

### Example 1: Extract Factors and Optimize Portfolio

```python
import numpy as np
from factor_lab import (
    svd_decomposition,
    FactorOptimizer,
    ScenarioBuilder,
    save_model,
)

# Generate or load returns data
returns = np.random.randn(1000, 100)  # 1000 periods, 100 assets

# Extract 5-factor model using SVD
model = svd_decomposition(returns, k=5)

print(f"Extracted {model.k} factors for {model.p} assets")

# Build optimization scenario
builder = ScenarioBuilder(p=100)
scenario = (builder
    .create("Long Only Fully Invested")
    .add_fully_invested()
    .add_long_only()
    .add_box_constraints(low=0.0, high=0.10)  # Max 10% per asset
    .build())

# Optimize
optimizer = FactorOptimizer(model)
optimizer.apply_scenario(scenario)
result = optimizer.solve()

if result.solved:
    print(f"Optimal portfolio risk: {result.risk:.2%}")
    print(f"Top 5 holdings: {np.argsort(result.weights)[-5:]}")
    
# Save for later use
save_model(model, "my_model.npz")
```

### Example 2: Simulate Returns with Custom Distributions

```python
from factor_lab import (
    FactorModelData,
    ReturnsSimulator,
    DistributionFactory,
    CovarianceValidator,
)

# Create or load a factor model
model = load_model("my_model.npz")

# Set up distribution factory
rng = np.random.default_rng(42)
factory = DistributionFactory(rng=rng)

# Create Student's t innovations (fat tails)
factor_samplers = [
    factory.create("student_t", df=5) 
    for _ in range(model.k)
]
idio_samplers = [
    factory.create("student_t", df=4) 
    for _ in range(model.p)
]

# Simulate 252 days of returns
simulator = ReturnsSimulator(model, rng=rng)
results = simulator.simulate(
    n_periods=252,
    factor_samplers=factor_samplers,
    idio_samplers=idio_samplers
)

# Extract components
security_returns = results["security_returns"]  # (252, p)
factor_returns = results["factor_returns"]      # (252, k)
idio_returns = results["idio_returns"]          # (252, p)

# Validate covariance structure
validator = CovarianceValidator(model)
validation = validator.compare(security_returns)

print(f"Frobenius error: {validation.frobenius_error:.4f}")
print(f"Explained variance: {validation.explained_variance_ratio:.2%}")
```

### Example 3: Build Custom Factor Model

```python
from factor_lab import FactorModelData

# Define your factor model components
k, p = 3, 50  # 3 factors, 50 assets

# Factor loadings (e.g., market, size, value)
B = np.random.randn(k, p)

# Factor covariance (diagonal = independent factors)
F = np.diag([0.04, 0.01, 0.0025])  # Market, size, value vols

# Idiosyncratic covariance (diagonal = no cross-sectional correlation)
D = np.diag(np.random.uniform(0.001, 0.01, p))

# Create model
model = FactorModelData(B=B, F=F, D=D)

# Model automatically validates on construction
print(f"Model: {model.k} factors × {model.p} assets")
print(f"Implied portfolio variance: {model.implied_covariance()[0, 0]:.6f}")
```

## 📚 Documentation

- **[API Reference](API.md)**: Complete API documentation for all modules
- **[Cheatsheet](CHEATSHEET.md)**: Quick reference for common tasks
- **[Examples](examples/)**: Detailed example scripts
- **[Contributing](CONTRIBUTING.md)**: Guidelines for contributors

## 🧪 Testing

The package includes comprehensive tests (172+ test cases):

```bash
# Run all tests
pytest tests/

# Run with coverage
pytest tests/ --cov=factor_lab --cov-report=html

# Run specific test module
pytest tests/test_optimization.py -v
```

## 📊 Performance

Factor models enable efficient computation for large portfolios:

| Operation | Full Covariance | Factor Model | Speedup |
|-----------|----------------|--------------|---------|
| p=500, k=5 optimization | O(500²) | O(5²) | ~100x |
| p=1000, k=10 simulation | O(1000²) | O(10²) | ~1000x |
| Covariance storage | 500k elements | 5k elements | 100x |

## 🏗️ Architecture

```
factor_lab/
├── types.py           # Core data structures
├── decomposition.py   # PCA/SVD factor extraction
├── simulator.py       # Monte Carlo simulation
├── validation.py      # Covariance validation
├── optimizer.py       # Portfolio optimization
├── constraints.py     # Optimization scenarios
├── distributions.py   # Statistical distributions
├── data_sampler.py    # Synthetic data generation
└── io.py             # Model serialization
```

## 🔬 Mathematical Foundation

### Factor Model Structure

A factor model decomposes asset returns as:

```
r = B.T @ f + ε
```

Where:
- `r`: (p,) vector of asset returns
- `B`: (k, p) matrix of factor loadings
- `f`: (k,) vector of factor returns with covariance F
- `ε`: (p,) vector of idiosyncratic returns with covariance D

The implied covariance is:

```
Σ = B.T @ F @ B + D
```

### Optimization Formulation

The minimum variance problem:

```
minimize    w.T @ Σ @ w
subject to  A_eq @ w = b_eq
            A_ineq @ w <= b_ineq
```

Is reformulated as an SOCP:

```
minimize    ||D^(1/2) @ w||² + ||F^(1/2) @ y||²
subject to  y = B @ w
            A_eq @ w = b_eq
            A_ineq @ w <= b_ineq
```

This reduces complexity from O(p²) to O(k²).

## 🤝 Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

Key areas for contribution:
- Additional distribution families
- Advanced optimization scenarios
- Performance optimizations
- Documentation improvements

## 📄 License

This project is licensed under the MIT License - see [LICENSE](LICENSE) file for details.

## 📮 Contact

- **Issues**: [GitHub Issues](https://github.com/yourusername/factor_lab/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/factor_lab/discussions)

## 🙏 Acknowledgments

- Built on CVXPY for convex optimization
- Uses NumPy/SciPy for numerical computations
- Inspired by modern portfolio theory and factor models in quantitative finance

## 📈 Roadmap

### Version 2.2 (Planned)
- [ ] Time-varying factor models (Kalman filtering)
- [ ] Risk attribution and decomposition
- [ ] Backtesting framework integration
- [ ] Multi-period optimization

### Version 2.3 (Future)
- [ ] Machine learning factor discovery
- [ ] Robust optimization under uncertainty
- [ ] Transaction cost modeling
- [ ] Real-time data integration

## 📖 Citation

If you use factor_lab in academic work, please cite:

```bibtex
@software{factor_lab,
  title = {factor_lab: A Python Library for Factor Models and Portfolio Optimization},
  author = {Your Name},
  year = {2024},
  version = {2.1.0},
  url = {https://github.com/yourusername/factor_lab}
}
```

---

**Version**: 2.1.0 | **Last Updated**: January 2026 | **Status**: Active Development
